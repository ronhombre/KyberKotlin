NO JAVADOCS!

Kotlin Multiplatform does not support Javadocs. Please visit the repository for more information.

https://github.com/ronhombre/KyberKotlin